# from pyhton_OOP.classes_and_objects.vehicle import Vehicle
from project.vehicle import Vehicle


class Car(Vehicle):

    def drive(self):
        return "driving..."