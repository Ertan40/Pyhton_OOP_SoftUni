# from pyhton_OOP.first_steps_in_OOP.car import Car
from project.car import Car


class SportsCar(Car):

    def race(self):
        return "racing..."