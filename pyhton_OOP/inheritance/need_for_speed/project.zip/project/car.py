# from pyhton_OOP.inheritance.need_for_speed.project.vehicle import Vehicle
from project.vehicle import Vehicle


class Car(Vehicle):
    DEFAULT_FUEL_CONSUMPTION = 3


