# from pyhton_OOP.inheritance.need_for_speed.project.vehicle import Vehicle
from project.vehicle import Vehicle


class Motorcycle(Vehicle):
    pass