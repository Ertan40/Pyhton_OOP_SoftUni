# from pyhton_OOP.inheritance.need_for_speed.project.car import Car
from project.car import Car


class FamilyCar(Car):
    pass

# print(FamilyCar.DEFAULT_FUEL_CONSUMPTION)
# family_car = FamilyCar(150, 150)
# family_car.drive(50)
# print(family_car.fuel)
# family_car.drive(50)
# print(family_car.fuel)
# print(family_car.__class__.__bases__[0].__name__)