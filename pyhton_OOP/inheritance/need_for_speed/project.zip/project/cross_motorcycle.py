# from pyhton_OOP.inheritance.need_for_speed.project.motorcycle import Motorcycle
from project.motorcycle import Motorcycle


class CrossMotorcycle(Motorcycle):
    pass