# from pyhton_OOP.inheritance.need_for_speed.project.car import Car
from project.car import Car


class SportCar(Car):
    DEFAULT_FUEL_CONSUMPTION = 10
