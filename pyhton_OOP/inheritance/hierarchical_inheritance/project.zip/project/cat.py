# from pyhton_OOP.inheritance.single_inheritance.project.animal import Animal
from project.animal import Animal


class Cat(Animal):
    def meow(self):
        return "meowing..."